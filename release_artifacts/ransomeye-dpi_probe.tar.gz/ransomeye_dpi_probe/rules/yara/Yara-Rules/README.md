                                                                
#### Yara-Rules ####

Repository of YARA rules to accompany the Trellix ATR blogposts & investigations

We endorse contributing to improve our rules - please send us a pull request with your proposal

In case you discovered a false positive with our rules, please share with us your details in an issue report and we’ll try to improve our Yara rules.

Happy Hunting!

