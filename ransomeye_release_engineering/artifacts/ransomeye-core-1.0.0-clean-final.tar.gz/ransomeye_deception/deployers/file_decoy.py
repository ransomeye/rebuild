# Path and File Name : /home/ransomeye/rebuild/ransomeye_deception/deployers/file_decoy.py
# Author: nXxBku0CKFAJCBN3X1g3bQk7OxYQylg8CMw1iGsq7gU
# Details of functionality of this file: Creates honeyfiles with synthetic content and tracks file access via filesystem watchers

import os
import sys
import hashlib
import random
import string
from pathlib import Path
from typing import Dict, Any, Optional
import logging
import asyncio
from datetime import datetime

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Try to import watchdog for real-time monitoring
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    logger.warning("watchdog not available, using polling for file access detection")


class FileAccessHandler(FileSystemEventHandler):
    """Handler for file system events."""
    
    def __init__(self, decoy_id: str, callback):
        self.decoy_id = decoy_id
        self.callback = callback
        super().__init__()
    
    def on_accessed(self, event):
        """Called when file is accessed."""
        if not event.is_directory:
            asyncio.create_task(self.callback(self.decoy_id, event.src_path, 'accessed'))
    
    def on_modified(self, event):
        """Called when file is modified."""
        if not event.is_directory:
            asyncio.create_task(self.callback(self.decoy_id, event.src_path, 'modified'))


class FileDecoy:
    """
    File decoy deployer.
    Creates honeyfiles with enticing content and monitors access.
    """
    
    def __init__(self):
        """Initialize file decoy deployer."""
        self.active_decoys = {}  # decoy_id -> {path, observer, handler}
        self.observers = {}  # decoy_id -> Observer
        
        # Synthetic content templates
        self.content_templates = {
            'passwords.txt': self._generate_password_file,
            'credentials.txt': self._generate_credentials_file,
            'secret.key': self._generate_key_file,
            'budget.xlsx': self._generate_budget_file,
            'employee_data.csv': self._generate_employee_data,
            'config.ini': self._generate_config_file,
            'backup.tar.gz': self._generate_backup_file,
            'database_dump.sql': self._generate_database_dump
        }
        
        logger.info("File decoy deployer initialized")
    
    def _generate_password_file(self) -> str:
        """Generate password file content."""
        lines = [
            "# Internal Password Vault",
            "# Last Updated: 2024-01-15",
            "",
            "ADMIN_PASSWORD=SuperSecret2024!",
            "DB_PASSWORD=SecureDBPass123",
            "API_KEY=sk_live_51aBcDeFgHiJkLmNoPqRsTuVwXyZ",
            "ROOT_ACCESS=root:Password123!",
            "",
            "# Production Credentials",
            "PROD_DB=postgres://admin:ProdPass456@db.internal:5432/prod",
            "REDIS_PASS=redis_secret_key_789"
        ]
        return "\n".join(lines)
    
    def _generate_credentials_file(self) -> str:
        """Generate credentials file content."""
        users = [
            ("admin", "Admin@2024!"),
            ("root", "RootPass789!"),
            ("service", "ServiceAccount2024"),
            ("backup", "BackupUser123!")
        ]
        lines = ["# System Credentials", ""]
        for user, pwd in users:
            lines.append(f"{user}:{pwd}")
        return "\n".join(lines)
    
    def _generate_key_file(self) -> str:
        """Generate secret key file content."""
        key = "".join(random.choices(string.ascii_letters + string.digits, k=64))
        return f"-----BEGIN PRIVATE KEY-----\n{key}\n-----END PRIVATE KEY-----"
    
    def _generate_budget_file(self) -> str:
        """Generate budget file content (fake CSV)."""
        lines = [
            "Department,Q1,Q2,Q3,Q4,Total",
            "IT,$250000,$275000,$300000,$325000,$1150000",
            "Security,$150000,$165000,$180000,$195000,$690000",
            "Operations,$500000,$550000,$600000,$650000,$2300000",
            "TOTAL,$900000,$990000,$1080000,$1170000,$4140000"
        ]
        return "\n".join(lines)
    
    def _generate_employee_data(self) -> str:
        """Generate employee data CSV."""
        lines = [
            "ID,Name,Email,Salary,SSN",
            "1001,John Doe,john.doe@company.com,75000,123-45-6789",
            "1002,Jane Smith,jane.smith@company.com,82000,987-65-4321",
            "1003,Bob Johnson,bob.j@company.com,68000,555-12-3456"
        ]
        return "\n".join(lines)
    
    def _generate_config_file(self) -> str:
        """Generate config file content."""
        lines = [
            "[database]",
            "host=db.internal.company.com",
            "port=5432",
            "user=admin",
            "password=ConfigPassword123!",
            "",
            "[api]",
            "api_key=AKIAIOSFODNN7EXAMPLE",
            "secret_key=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            "",
            "[backup]",
            "s3_bucket=company-backups",
            "access_key=backup_access_2024"
        ]
        return "\n".join(lines)
    
    def _generate_backup_file(self) -> str:
        """Generate fake backup file content (binary-like)."""
        # Generate pseudo-binary content
        content = b"BZ\x90\x1a\x01\x00" + bytes(random.choices(range(256), k=1000))
        return content.decode('latin-1', errors='ignore')
    
    def _generate_database_dump(self) -> str:
        """Generate database dump content."""
        lines = [
            "-- MySQL dump 10.13",
            "-- Host: db.internal    Database: production",
            "",
            "CREATE TABLE users (",
            "  id INT PRIMARY KEY,",
            "  username VARCHAR(50),",
            "  password_hash VARCHAR(255)",
            ");",
            "",
            "INSERT INTO users VALUES (1, 'admin', '$2y$10$N9qo8uLOickgx2ZMRZoMye');",
            "INSERT INTO users VALUES (2, 'user1', '$2y$10$abcdefghijklmnopqrstuv');"
        ]
        return "\n".join(lines)
    
    def _get_content_for_file(self, file_path: str) -> str:
        """Get appropriate content for file based on name."""
        filename = Path(file_path).name.lower()
        
        for pattern, generator in self.content_templates.items():
            if pattern in filename:
                return generator()
        
        # Default content
        return f"# Confidential File\n# Created: {datetime.utcnow().isoformat()}\n# Do not distribute"
    
    async def provision(self, decoy_id: str, location: str,
                       metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Provision a file decoy.
        
        Args:
            decoy_id: Unique decoy ID
            location: File path
            metadata: Optional metadata
            
        Returns:
            Provision result
        """
        try:
            file_path = Path(location)
            
            # Create parent directory if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Generate content
            content = self._get_content_for_file(str(file_path))
            
            # Write file
            if isinstance(content, str):
                file_path.write_text(content, encoding='utf-8')
            else:
                file_path.write_bytes(content.encode('utf-8', errors='ignore'))
            
            # Set permissions to make it accessible but not suspiciously open
            os.chmod(file_path, 0o644)
            
            # Calculate hash
            file_hash = hashlib.sha256(content.encode('utf-8') if isinstance(content, str) else content).hexdigest()
            
            # Setup monitoring
            initial_stat = file_path.stat()
            
            # Store decoy info
            decoy_info = {
                'path': str(file_path),
                'hash': file_hash,
                'initial_atime': initial_stat.st_atime,
                'initial_mtime': initial_stat.st_mtime,
                'created_at': datetime.utcnow().isoformat()
            }
            
            # Start file watcher if available
            if WATCHDOG_AVAILABLE:
                observer = Observer()
                handler = FileAccessHandler(decoy_id, self._on_file_event)
                observer.schedule(handler, str(file_path.parent), recursive=False)
                observer.start()
                
                self.observers[decoy_id] = observer
                self.active_decoys[decoy_id] = {
                    **decoy_info,
                    'observer': observer,
                    'handler': handler
                }
            else:
                self.active_decoys[decoy_id] = decoy_info
            
            logger.info(f"File decoy provisioned: {file_path}")
            
            return {
                'decoy_id': decoy_id,
                'type': 'file',
                'path': str(file_path),
                'hash': file_hash,
                'size': file_path.stat().st_size
            }
            
        except Exception as e:
            logger.error(f"Error provisioning file decoy: {e}")
            raise
    
    async def verify(self, decoy_id: str, provision_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify file decoy is active.
        
        Args:
            decoy_id: Decoy ID
            provision_result: Provision result
            
        Returns:
            Verification result
        """
        try:
            file_path = Path(provision_result['path'])
            
            if not file_path.exists():
                return {
                    'verified': False,
                    'error': 'File does not exist'
                }
            
            # Check hash matches
            current_content = file_path.read_text(encoding='utf-8')
            current_hash = hashlib.sha256(current_content.encode('utf-8')).hexdigest()
            
            if current_hash != provision_result.get('hash'):
                return {
                    'verified': False,
                    'error': 'File content hash mismatch'
                }
            
            return {
                'verified': True,
                'path': str(file_path),
                'size': file_path.stat().st_size
            }
            
        except Exception as e:
            return {
                'verified': False,
                'error': str(e)
            }
    
    async def deprovision(self, decoy_id: str, provision_result: Dict[str, Any]):
        """
        Deprovision file decoy.
        
        Args:
            decoy_id: Decoy ID
            provision_result: Provision result
        """
        try:
            # Stop observer if active
            if decoy_id in self.observers:
                self.observers[decoy_id].stop()
                self.observers[decoy_id].join()
                del self.observers[decoy_id]
            
            # Remove file
            if decoy_id in self.active_decoys:
                file_path = Path(self.active_decoys[decoy_id]['path'])
                if file_path.exists():
                    file_path.unlink()
                    logger.info(f"File decoy removed: {file_path}")
                
                del self.active_decoys[decoy_id]
            
        except Exception as e:
            logger.error(f"Error deprovisioning file decoy: {e}")
            raise
    
    async def _on_file_event(self, decoy_id: str, file_path: str, event_type: str):
        """Callback for file access events."""
        logger.info(f"File decoy {decoy_id} accessed: {file_path} ({event_type})")
        # This will be called by monitor/decoy_monitor.py to generate alerts

